/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React, { useState, useEffect } from 'react';

const loadingMessages = [
  'Lacing up the virtual boots...',
  'Reviewing the VAR footage for the perfect angle...',
  'Warming up the AI striker...',
  'The digital crowd is roaring...',
  'This might go to extra time, please wait...',
  'Building the stadium pixel by pixel...',
  'Analyzing the tactics for this shot...',
  'Waiting for the final whistle on this render...',
  'Setting up the perfect free-kick...',
  "Recreating that top-corner screamer...",
  "It's a game of two halves, and we're in the second.",
  'The AI is on a hat-trick of good renders...',
];

const LoadingIndicator: React.FC = () => {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setMessageIndex((prevIndex) => (prevIndex + 1) % loadingMessages.length);
    }, 3000); // Change message every 3 seconds

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-12 bg-gray-800/50 rounded-lg border border-gray-700">
      <div className="w-16 h-16 border-4 border-t-transparent border-indigo-500 rounded-full animate-spin"></div>
      <h2 className="text-2xl font-semibold mt-8 text-gray-200">Generating Your Video</h2>
      <p className="mt-2 text-gray-400 text-center transition-opacity duration-500">
        {loadingMessages[messageIndex]}
      </p>
    </div>
  );
};

export default LoadingIndicator;
